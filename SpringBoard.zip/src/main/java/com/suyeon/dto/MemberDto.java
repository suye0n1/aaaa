package com.suyeon.dto;


import lombok.Data;

@Data
public class MemberDto {

	private String username;
	private String user_id;
	private String passwd;
	private String pw_ch;
	private String name;	
	private String email;
}
