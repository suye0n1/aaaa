package com.suyeon.mapper;

import java.util.List;

import com.suyeon.dto.BoardDto;

public interface BoardMapper {
	public List<BoardDto> list(String castegory);
	public BoardDto read(long num);
	public void del(long num);
	public void viewCount(long num);
	public void write(BoardDto dto);
}
