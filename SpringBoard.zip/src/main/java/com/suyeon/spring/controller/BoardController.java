package com.suyeon.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.suyeon.dto.BoardDto;
import com.suyeon.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/board/*")
@AllArgsConstructor
@SessionAttributes("login")
@Controller
public class BoardController {
	
	private BoardService service;
	
	//1.리스트
	@GetMapping("/list")
	public void list(@RequestParam("category") String category, Model model) {
		model.addAttribute("list", service.list(category));
	}
	
	//2.읽기
	@GetMapping({"/read", "/modify"})
	public void read(@RequestParam("num") Long num, Model model) {
		log.info("컨트롤러"+num);
		model.addAttribute("read", service.read(num));
	}
	
	//삭제
	@GetMapping("/del")
	public String del(@RequestParam("num") Long num){
		log.info("컨트롤러"+num);
		service.del(num);
		return "redirect:/board/list";
	}
	
	//쓰기 화면 출력
	@GetMapping("/write")
	public void write() {
		
	}
	
	//쓰기
	@PostMapping("/write")
	public String write(BoardDto dto) {
		service.write(dto);
		return "redirect:/";	//category???
	}
	
	
	
	//수정
//	@GetMapping("/modify")
//	public String modify(BoardDto dto) {
//		service.modify(dto);
//		return "redirect:/";		
//	}
}
